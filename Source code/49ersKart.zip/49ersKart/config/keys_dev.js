module.exports = {
    stripePublishableKey: 'pk_test_85gPd21zQGii2PjtBZ4tGJ6a00Ezdw2C1p',
    stripeSecretKey: 'sk_test_CUKF5671jNZFdAMU8uPG2Jz100aJkcoVIJ'
}